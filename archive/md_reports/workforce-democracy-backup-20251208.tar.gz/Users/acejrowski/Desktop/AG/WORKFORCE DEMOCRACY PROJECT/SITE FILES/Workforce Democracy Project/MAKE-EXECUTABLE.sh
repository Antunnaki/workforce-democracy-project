#!/bin/bash
# Make deployment script executable

chmod +x deploy-v37.11.6-backend.sh

echo "✅ Deployment script is now executable!"
echo ""
echo "Run it with:"
echo "./deploy-v37.11.6-backend.sh"
