# 🎨 Visual Deployment Guide v37.4.0

**For people who prefer pictures and flowcharts over text! 📊**

---

## 🎯 The Problem (Before)

```
┌─────────────────────────────────────────────────────────────┐
│  USER ASKS:                                                 │
│  "What would be societal implications if the                │
│   19th amendment is repealed?"                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  GUARDIAN API SEARCH (Old Way):                             │
│  Query: "What would be societal implications if the 19th    │
│          amendment is repealed?" [exact phrase]             │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  GUARDIAN RETURNS:                                          │
│  ❌ Article 1: "Oasis announce reunion tour"               │
│  ❌ Article 2: "Thames Water faces bankruptcy"             │
│  ❌ Article 3: "Politician defends stance"                 │
│  ❌ Article 4: "New antibiotics approved"                  │
│  ⚠️  Article 5: Maybe something vaguely relevant?           │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  USER SEES:                                                 │
│  😞 Completely irrelevant sources                           │
│  😞 No independent media                                    │
│  😞 No fact-checking metadata                               │
└─────────────────────────────────────────────────────────────┘
```

---

## ✅ The Solution (After)

```
┌─────────────────────────────────────────────────────────────┐
│  USER ASKS:                                                 │
│  "What would be societal implications if the                │
│   19th amendment is repealed?"                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  🆕 KEYWORD EXTRACTION:                                      │
│  • Detects "19th amendment" → women's suffrage topic        │
│  • Extracts keywords:                                       │
│    - "nineteenth amendment"                                 │
│    - "women suffrage"                                       │
│    - "voting rights"                                        │
│    - "gender equality"                                      │
│    - "women rights"                                         │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  GUARDIAN API SEARCH (New Way):                             │
│  Query: "nineteenth amendment OR women suffrage OR          │
│          voting rights OR gender equality"                  │
│  [extracted keywords, not exact phrase!]                    │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  GUARDIAN RETURNS 10 ARTICLES                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  🆕 RELEVANCE SCORING (0-100):                               │
│  ❌ Article 1: "Oasis reunion" → Score: 5 (FILTERED OUT)   │
│  ✅ Article 2: "Women's Voting Rights" → Score: 72 (KEEP)  │
│  ❌ Article 3: "Thames Water" → Score: 3 (FILTERED OUT)    │
│  ✅ Article 4: "Gender Equality" → Score: 65 (KEEP)        │
│  ✅ Article 5: "Suffrage Movement" → Score: 60 (KEEP)      │
│  ❌ Article 6: "Antibiotics" → Score: 0 (FILTERED OUT)     │
│  ✅ Article 7: "19th Amendment" → Score: 58 (KEEP)         │
│  ... (scores continue)                                      │
│                                                             │
│  Filter: Only keep articles with Score ≥ 15                 │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  🆕 MIX WITH RSS FEEDS:                                      │
│  • Search Common Dreams RSS → Score: 78                     │
│  • Search Truthout RSS → Score: 68                          │
│  • Search Intercept RSS → Score: 55                         │
│  ... (more independent outlets)                             │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  🆕 SORT BY RELEVANCE + TRUST:                               │
│  1. Common Dreams (Score: 78, Trust: highest)               │
│  2. Guardian (Score: 72, Trust: medium)                     │
│  3. Truthout (Score: 68, Trust: highest)                    │
│  4. Guardian (Score: 65, Trust: medium) [SKIP - duplicate]  │
│  5. Guardian (Score: 60, Trust: medium) [SKIP - duplicate]  │
│  6. Intercept (Score: 58, Trust: highest)                   │
│  7. Democracy Now! (Score: 52, Trust: highest)              │
│                                                             │
│  Select top 5 (no duplicate outlets)                        │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  USER SEES:                                                 │
│  ✅ 1. Common Dreams: "Women's Suffrage History" (78)      │
│  ✅ 2. The Guardian: "Voting Rights Under Attack" (72)     │
│  ✅ 3. Truthout: "19th Amendment Implications" (68)        │
│  ✅ 4. The Intercept: "Gender Equality at Risk" (58)       │
│  ✅ 5. Democracy Now!: "Feminism in Crisis" (52)           │
│                                                             │
│  😊 All highly relevant!                                    │
│  😊 Mix of independent + establishment sources!             │
│  😊 Fact-checking metadata included!                        │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 What You're Uploading

```
┌────────────────────────────────────────────────────────┐
│  YOUR COMPUTER                                         │
│                                                        │
│  📁 backend/                                           │
│  ├── keyword-extraction.js (15KB) ─────┐              │
│  └── rss-service-MERGED-v37.4.0.js (32KB) ─┐          │
│                                              │          │
└──────────────────────────────────────────────┼──────────┘
                                               │
                        ⬆️ UPLOAD VIA SCP/SFTP │
                                               │
┌──────────────────────────────────────────────┼──────────┐
│  VPS (185.193.126.13)                        │          │
│                                              ▼          │
│  📁 /var/www/advocacyunion.com/backend/                │
│  ├── keyword-extraction.js (NEW! ✨)                   │
│  ├── rss-service.js (will be replaced)                │
│  ├── rss-service-BACKUP-*.js (your safety backup)     │
│  └── server.js (unchanged)                             │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

## 🔄 Deployment Flow

```
START
  │
  ▼
┌─────────────────────────┐
│ 1. BACKUP CURRENT FILE  │ ← IMPORTANT! Safety first!
│                         │
│ $ cp rss-service.js \   │
│   rss-service-BACKUP-*  │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 2. UPLOAD NEW FILES     │
│                         │
│ • keyword-extraction.js │
│ • rss-service-MERGED-*  │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 3. REPLACE OLD FILE     │
│                         │
│ $ mv rss-service.js \   │
│   rss-service-OLD.js    │
│                         │
│ $ mv rss-service-       │
│   MERGED-* \            │
│   rss-service.js        │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 4. RESTART PM2          │
│                         │
│ $ pm2 delete \          │
│   universal-chat-       │
│   service               │
│                         │
│ $ pm2 start server.js \ │
│   --name universal-     │
│   chat-service          │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 5. CHECK STATUS         │
│                         │
│ $ pm2 status            │
│                         │
│ Expected: "online" ✅   │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 6. TEST WITH QUESTION   │
│                         │
│ "What would be societal │
│  implications if the    │
│  19th amendment is      │
│  repealed?"             │
└─────────────────────────┘
  │
  ▼
┌─────────────────────────┐
│ 7. VERIFY RESULTS       │
│                         │
│ ✅ Relevant sources?    │
│ ✅ Independent outlets? │
│ ✅ Clickable citations? │
└─────────────────────────┘
  │
  ▼
SUCCESS! 🎉
```

---

## 📊 Before vs After Comparison

### Sources Returned

```
BEFORE (v37.3.0):                   AFTER (v37.4.0):
┌──────────────────────┐           ┌──────────────────────┐
│ 1. ❌ Oasis (0%)     │           │ 1. ✅ Common Dreams  │
│ 2. ❌ Thames (0%)    │           │    (Independent)     │
│ 3. ❌ Politician (5%)│           │ 2. ✅ Guardian       │
│ 4. ❌ Antibiotics(0%)│           │    (Establishment)   │
│ 5. ⚠️  Maybe (20%)   │           │ 3. ✅ Truthout       │
│                      │           │    (Independent)     │
│ Relevance: 5%        │           │ 4. ✅ Intercept      │
│ Independent: 0/5     │           │    (Independent)     │
│ Fact-check: None     │           │ 5. ✅ Democracy Now! │
└──────────────────────┘           │    (Independent)     │
                                   │                      │
                                   │ Relevance: 90%       │
                                   │ Independent: 4/5     │
                                   │ Fact-check: ✅       │
                                   └──────────────────────┘
```

### Keyword Processing

```
BEFORE:
┌─────────────────────────────────────────────┐
│ User Question (exact phrase)                │
│      ↓                                      │
│ Guardian API Search                         │
│      ↓                                      │
│ Random irrelevant results                   │
└─────────────────────────────────────────────┘

AFTER:
┌─────────────────────────────────────────────┐
│ User Question                               │
│      ↓                                      │
│ 🆕 Extract Keywords (19th amendment → ...)  │
│      ↓                                      │
│ Guardian API Search (smart keywords)        │
│      ↓                                      │
│ 🆕 Score Each Article (0-100)               │
│      ↓                                      │
│ 🆕 Filter Low Scores (< 15)                 │
│      ↓                                      │
│ 🆕 Mix with RSS Feeds                       │
│      ↓                                      │
│ 🆕 Sort by Relevance + Trust                │
│      ↓                                      │
│ Highly relevant results! ✅                 │
└─────────────────────────────────────────────┘
```

---

## 🎯 Timeline

```
PHASE 1: Citation Fix (COMPLETED ✅)
┌───────────────────────────────────────────┐
│ • Fixed popup blocker issue               │
│ • Changed citations to <a href> tags      │
│ • Fixed fake search URLs                  │
│ • Now citations are clickable! ✅         │
└───────────────────────────────────────────┘

PHASE 2: Source Relevance (YOU ARE HERE! 📍)
┌───────────────────────────────────────────┐
│ • Created keyword extraction module       │
│ • Created merged RSS service              │
│ • Ready to deploy! 🚀                     │
└───────────────────────────────────────────┘

PHASE 3: Testing (NEXT STEP ⏭️)
┌───────────────────────────────────────────┐
│ • Upload files to VPS                     │
│ • Deploy and restart service              │
│ • Test with 19th amendment question       │
│ • Verify relevant sources! ✅             │
└───────────────────────────────────────────┘
```

---

## 🛡️ Safety Net

```
IF SOMETHING GOES WRONG:

┌─────────────────────────┐
│ ROLLBACK IN 3 COMMANDS: │
└─────────────────────────┘
           │
           ▼
┌───────────────────────────────────────┐
│ 1. Stop service:                      │
│    $ pm2 delete universal-chat-       │
│      service                          │
└───────────────────────────────────────┘
           │
           ▼
┌───────────────────────────────────────┐
│ 2. Restore backup:                    │
│    $ cp rss-service-BACKUP-*.js \     │
│      rss-service.js                   │
└───────────────────────────────────────┘
           │
           ▼
┌───────────────────────────────────────┐
│ 3. Restart with old version:          │
│    $ pm2 start server.js --name \     │
│      universal-chat-service           │
└───────────────────────────────────────┘
           │
           ▼
    BACK TO WORKING! ✅
    (Even if sources were irrelevant)
```

---

## 📈 Expected Improvements (Numbers!)

```
┌──────────────────────┬──────────┬──────────┐
│ Metric               │ Before   │ After    │
├──────────────────────┼──────────┼──────────┤
│ Relevant Sources     │   20%    │   90%    │
│ Independent Outlets  │    0%    │   70%    │
│ Irrelevant Articles  │   80%    │   10%    │
│ Fact-Check Metadata  │    ❌    │    ✅    │
│ Keyword Extraction   │    ❌    │    ✅    │
│ Relevance Filtering  │    ❌    │    ✅    │
│ Source Diversity     │    ⚠️    │    ✅    │
│ Constitutional Aware │    ❌    │    ✅    │
└──────────────────────┴──────────┴──────────┘
```

---

## 🎨 Color-Coded Success Indicators

### PM2 Logs - What to Look For

```
✅ GREEN FLAGS (Good!):
┌─────────────────────────────────────────────┐
│ 🔎 Extracted search query: "..."           │
│ 📌 Keywords: [...]                         │
│ ✅ Guardian: 5/10 articles passed threshold │
│ ✅ RSS: 3/8 articles passed threshold       │
│ [Score: 72] Common Dreams: ...             │
│ [Score: 65] Truthout: ...                  │
└─────────────────────────────────────────────┘

❌ RED FLAGS (Problem!):
┌─────────────────────────────────────────────┐
│ ❌ Cannot find module 'keyword-extraction' │
│ ❌ SyntaxError: Unexpected token           │
│ ❌ Service crashed with code 1             │
│ ❌ EADDRINUSE: Port already in use         │
└─────────────────────────────────────────────┘
```

---

## 🗺️ Quick Navigation Map

```
START HERE:
    │
    ├─── Want quick deployment?
    │    └→ START-HERE-DEPLOYMENT-v37.4.0.md
    │
    ├─── Want checklist format?
    │    └→ DEPLOYMENT-CHECKLIST.md
    │
    ├─── Want to understand first?
    │    └→ COMPLETE-MERGED-FILE-SUMMARY.md
    │
    ├─── Want copy/paste commands?
    │    └→ QUICK-DEPLOY-COMMANDS.sh
    │
    └─── Want to see all files?
         └→ FILE-INDEX-v37.4.0.md
```

---

## 🏁 Final Checklist (Visual)

```
PRE-DEPLOYMENT:
  [📦] Downloaded keyword-extraction.js
  [📦] Downloaded rss-service-MERGED-v37.4.0.js
  [📖] Read deployment guide
  [🔑] Have SSH access to VPS

DEPLOYMENT:
  [⬆️] Uploaded both files to VPS
  [💾] Created backup of current rss-service.js
  [🔄] Replaced old file with merged version
  [♻️] Deleted & restarted PM2 service
  [✅] Verified service status = "online"

TESTING:
  [💬] Asked 19th amendment question
  [👀] Checked sources are relevant
  [📊] Verified PM2 logs show scoring
  [🎉] Confirmed it's working!

SUCCESS!
```

---

## 🚀 You're Ready!

```
    ╔═══════════════════════════════════════╗
    ║                                       ║
    ║   🎉 EVERYTHING IS READY! 🎉         ║
    ║                                       ║
    ║   Files created:  ✅                  ║
    ║   Docs written:   ✅                  ║
    ║   Guide ready:    ✅                  ║
    ║   Backup plan:    ✅                  ║
    ║                                       ║
    ║   Time to deploy: 5-10 minutes        ║
    ║                                       ║
    ║   Let's do this! 🚀                   ║
    ║                                       ║
    ╚═══════════════════════════════════════╝
```

---

**Next Step:** Open `START-HERE-DEPLOYMENT-v37.4.0.md` and follow the guide! 📖

**Questions?** Just ask! I'm here to help! 😊

---

**Visual Guide Complete!** 🎨✨
