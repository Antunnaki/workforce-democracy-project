#!/bin/bash

##############################################################
# BACKEND STATUS CHECK - Run this on VPS
# Purpose: Check if backend is running on port 3001
##############################################################

echo "════════════════════════════════════════════════════════"
echo "🔍 CHECKING BACKEND STATUS"
echo "════════════════════════════════════════════════════════"
echo ""

echo "1️⃣ PM2 Process Status:"
echo "─────────────────────────────────────────────────────────"
/opt/nodejs/bin/pm2 status
echo ""

echo "2️⃣ PM2 Logs (Last 20 lines):"
echo "─────────────────────────────────────────────────────────"
/opt/nodejs/bin/pm2 logs backend --lines 20 --nostream
echo ""

echo "3️⃣ Port 3001 Status:"
echo "─────────────────────────────────────────────────────────"
if netstat -tulpn | grep -q :3001; then
    echo "✅ Port 3001 is LISTENING"
    netstat -tulpn | grep :3001
else
    echo "❌ Port 3001 is NOT listening"
    echo "🚨 PROBLEM: Backend should be listening on port 3001!"
fi
echo ""

echo "4️⃣ Test Backend Directly (localhost:3001):"
echo "─────────────────────────────────────────────────────────"
curl -s "http://localhost:3001/api/civic/representatives/search?zip=12061" | head -c 500
echo ""
echo ""

echo "5️⃣ Test Backend via Nginx (HTTPS):"
echo "─────────────────────────────────────────────────────────"
curl -s "https://api.workforcedemocracyproject.org/api/civic/representatives/search?zip=12061" | head -c 500
echo ""
echo ""

echo "════════════════════════════════════════════════════════"
echo "✅ STATUS CHECK COMPLETE"
echo "════════════════════════════════════════════════════════"
